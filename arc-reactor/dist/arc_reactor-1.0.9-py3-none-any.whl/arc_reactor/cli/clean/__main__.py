import arc_reactor.cli.init.downloader as downloader


def main():
    downloader.iniatiateFramework()