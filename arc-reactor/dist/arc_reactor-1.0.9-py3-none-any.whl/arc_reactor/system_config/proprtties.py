properties_json='''
{
    "version.check" : true
    "minimum.version.major" : 3
    "handle.exception.enabled" : true
    "handle.exception.exit.enabled" : true
    "hystrix.jumpto.enabled" : true
    "network.connection.check.enabled" : true
    "pip.install.enabled" : true
    "auto.package.install.enabled" : true
    "system.current.loging.level" : "info"
}
'''